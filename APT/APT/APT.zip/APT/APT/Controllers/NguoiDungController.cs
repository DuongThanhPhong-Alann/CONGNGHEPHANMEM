﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Services;
[Route("api/[controller]")]
[ApiController]
public class NguoiDungController : ControllerBase
{
    private readonly NguoiDungService _nguoiDungService;

    public NguoiDungController(NguoiDungService nguoiDungService)
    {
        _nguoiDungService = nguoiDungService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<NguoiDung>>> GetAll()
    {
        return Ok(await _nguoiDungService.GetAllAsync());
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<NguoiDung>> GetById(int id)
    {
        var nguoiDung = await _nguoiDungService.GetByIdAsync(id);
        if (nguoiDung == null) return NotFound();
        return Ok(nguoiDung);
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] NguoiDung nguoiDung)
    {
        await _nguoiDungService.AddAsync(nguoiDung);
        return CreatedAtAction(nameof(GetById), new { id = nguoiDung.ID }, nguoiDung);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromBody] NguoiDung nguoiDung)
    {
        if (id != nguoiDung.ID) return BadRequest();
        await _nguoiDungService.UpdateAsync(nguoiDung);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _nguoiDungService.DeleteAsync(id);
        return NoContent();
    }
}
