﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using APT.Services;
[Route("api/[controller]")]
[ApiController]
public class PhanAnhController : ControllerBase
{
    private readonly PhanAnhService _phanAnhService;

    public PhanAnhController(PhanAnhService phanAnhService)
    {
        _phanAnhService = phanAnhService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PhanAnh>>> GetAll()
    {
        return Ok(await _phanAnhService.GetAllAsync());
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] PhanAnh phanAnh)
    {
        await _phanAnhService.AddAsync(phanAnh);
        return CreatedAtAction(nameof(GetAll), phanAnh);
    }

    
}
