﻿using APT.Model;
using APT.Services;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class HinhAnhCanHoController : ControllerBase
{
    private readonly HinhAnhCanHoService _hinhAnhCanHoService;

    public HinhAnhCanHoController(HinhAnhCanHoService hinhAnhCanHoService)
    {
        _hinhAnhCanHoService = hinhAnhCanHoService;
    }

    // 📌 Lấy danh sách ảnh của một căn hộ
    [HttpGet("canho/{id}")]
    public async Task<IActionResult> GetByCanHoId(int id)
    {
        var result = await _hinhAnhCanHoService.GetByCanHoIdAsync(id);
        return Ok(result);
    }

    // 📌 Lấy hình ảnh theo ID
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await _hinhAnhCanHoService.GetByIdAsync(id);
        if (result == null) return NotFound();
        return Ok(result);
    }

    // 📌 Thêm hình ảnh mới
    [HttpPost]
    public async Task<IActionResult> Add([FromBody] HinhAnhCanHo hinhAnhCanHo)
    {
        var success = await _hinhAnhCanHoService.AddAsync(hinhAnhCanHo);
        if (!success) return BadRequest("Không thể thêm hình ảnh.");
        return Ok("Thêm thành công!");
    }

    // 📌 Cập nhật hình ảnh
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] HinhAnhCanHo hinhAnhCanHo)
    {
        if (id != hinhAnhCanHo.ID) return BadRequest("ID không khớp.");
        var success = await _hinhAnhCanHoService.UpdateAsync(hinhAnhCanHo);
        if (!success) return BadRequest("Không thể cập nhật.");
        return Ok("Cập nhật thành công!");
    }

    // 📌 Xóa hình ảnh
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var success = await _hinhAnhCanHoService.DeleteAsync(id);
        if (!success) return NotFound("Không tìm thấy hình ảnh để xóa.");
        return Ok("Xóa thành công!");
    }
}
