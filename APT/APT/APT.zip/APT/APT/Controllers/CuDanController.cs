﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Services;
[Route("api/[controller]")]
[ApiController]
public class CuDanController : ControllerBase
{
    private readonly CuDanService _cuDanService;

    public CuDanController(CuDanService cuDanService)
    {
        _cuDanService = cuDanService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CuDan>>> GetAll()
    {
        return Ok(await _cuDanService.GetAllAsync());
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<CuDan>> GetById(int id)
    {
        var cuDan = await _cuDanService.GetByIdAsync(id);
        if (cuDan == null) return NotFound();
        return Ok(cuDan);
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] CuDan cuDan)
    {
        await _cuDanService.AddAsync(cuDan);
        return CreatedAtAction(nameof(GetById), new { id = cuDan.ID }, cuDan);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromBody] CuDan cuDan)
    {
        if (id != cuDan.ID) return BadRequest();
        await _cuDanService.UpdateAsync(cuDan);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _cuDanService.DeleteAsync(id);
        return NoContent();
    }
}
