﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using APT.Services;

[Route("api/[controller]")]
[ApiController]
public class HoaDonDichVuController : ControllerBase
{
    private readonly HoaDonDichVuService _hoaDonService;

    public HoaDonDichVuController(HoaDonDichVuService hoaDonService)
    {
        _hoaDonService = hoaDonService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<HoaDonDichVu>>> GetAll()
    {
        return Ok(await _hoaDonService.GetAllAsync());
    }

}

public class ThanhToanRequest
{
    public int CanHoId { get; set; }
    public int DichVuId { get; set; }
}
