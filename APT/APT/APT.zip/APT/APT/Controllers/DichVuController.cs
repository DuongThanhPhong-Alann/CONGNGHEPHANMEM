﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Services;
[Route("api/[controller]")]
[ApiController]
public class DichVuController : ControllerBase
{
    private readonly DichVuService _dichVuService;

    public DichVuController(DichVuService dichVuService)
    {
        _dichVuService = dichVuService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<DichVu>>> GetAll()
    {
        return Ok(await _dichVuService.GetAllAsync());
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<DichVu>> GetById(int id)
    {
        var dichVu = await _dichVuService.GetByIdAsync(id);
        if (dichVu == null) return NotFound();
        return Ok(dichVu);
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] DichVu dichVu)
    {
        await _dichVuService.AddAsync(dichVu);
        return CreatedAtAction(nameof(GetById), new { id = dichVu.ID }, dichVu);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromBody] DichVu dichVu)
    {
        if (id != dichVu.ID) return BadRequest();
        await _dichVuService.UpdateAsync(dichVu);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _dichVuService.DeleteAsync(id);
        return NoContent();
    }
}
