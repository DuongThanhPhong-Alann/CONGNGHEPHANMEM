﻿using APT.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Services;

[Route("api/[controller]")]
[ApiController]
public class CanHoController : ControllerBase
{
    private readonly CanHoService _canHoService;

    public CanHoController(CanHoService canHoService)
    {
        _canHoService = canHoService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CanHo>>> GetAll()
    {
        return Ok(await _canHoService.GetAllAsync());
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<CanHo>> GetById(int id)
    {
        var canHo = await _canHoService.GetByIdAsync(id);
        if (canHo == null) return NotFound();
        return Ok(canHo);
    }

    [HttpPost]
    public async Task<ActionResult> Create([FromBody] CanHo canHo)
    {
        await _canHoService.AddAsync(canHo);
        return CreatedAtAction(nameof(GetById), new { id = canHo.ID }, canHo);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult> Update(int id, [FromBody] CanHo canHo)
    {
        if (id != canHo.ID) return BadRequest();
        await _canHoService.UpdateAsync(canHo);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        await _canHoService.DeleteAsync(id);
        return NoContent();
    }
}
