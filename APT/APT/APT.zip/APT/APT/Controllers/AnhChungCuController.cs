﻿using APT.Model;
using APT.Services;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class HinhAnhChungCuController : ControllerBase
{
    private readonly HinhAnhChungCuService _hinhAnhChungCuService;

    public HinhAnhChungCuController(HinhAnhChungCuService hinhAnhChungCuService)
    {
        _hinhAnhChungCuService = hinhAnhChungCuService;
    }

    // 📌 Lấy danh sách ảnh của một chung cư
    [HttpGet("chungcu/{id}")]
    public async Task<IActionResult> GetByChungCuId(int id)
    {
        var result = await _hinhAnhChungCuService.GetByChungCuIdAsync(id);
        return Ok(result);
    }

    // 📌 Lấy hình ảnh theo ID
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var result = await _hinhAnhChungCuService.GetByIdAsync(id);
        if (result == null) return NotFound();
        return Ok(result);
    }

    // 📌 Thêm hình ảnh mới
    [HttpPost]
    public async Task<IActionResult> Add([FromBody] HinhAnhChungCu hinhAnhChungCu)
    {
        var success = await _hinhAnhChungCuService.AddAsync(hinhAnhChungCu);
        if (!success) return BadRequest("Không thể thêm hình ảnh.");
        return Ok("Thêm thành công!");
    }

    // 📌 Cập nhật hình ảnh
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, [FromBody] HinhAnhChungCu hinhAnhChungCu)
    {
        if (id != hinhAnhChungCu.ID) return BadRequest("ID không khớp.");
        var success = await _hinhAnhChungCuService.UpdateAsync(hinhAnhChungCu);
        if (!success) return BadRequest("Không thể cập nhật.");
        return Ok("Cập nhật thành công!");
    }

    // 📌 Xóa hình ảnh
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var success = await _hinhAnhChungCuService.DeleteAsync(id);
        if (!success) return NotFound("Không tìm thấy hình ảnh để xóa.");
        return Ok("Xóa thành công!");
    }
}
