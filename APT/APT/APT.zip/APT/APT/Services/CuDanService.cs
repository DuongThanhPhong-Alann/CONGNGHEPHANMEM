﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;


using APT.Repositories;


namespace APT.Services
{
    public class CuDanService : ServiceBase<CuDan>
    {
        private readonly CuDanRepository _repository;

        public CuDanService(CuDanRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<CuDan>> GetAllWithDetailsAsync()
        {
            return await _repository.GetAllWithDetailsAsync();
        }
    }
}
