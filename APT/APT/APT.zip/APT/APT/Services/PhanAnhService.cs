﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;

using APT.Repositories;


namespace APT.Services
{
    public class PhanAnhService : ServiceBase<PhanAnh>
    {
        private readonly PhanAnhRepository _repository;

        public PhanAnhService(PhanAnhRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<PhanAnh>> GetAllWithUserAsync()
        {
            return await _repository.GetAllWithUserAsync();
        }
    }
}