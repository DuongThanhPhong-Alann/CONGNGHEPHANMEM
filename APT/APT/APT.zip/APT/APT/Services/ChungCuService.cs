﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;

using APT.Repositories;


namespace APT.Services
{
    public class ChungCuService : ServiceBase<ChungCu>
    {
        private readonly ChungCuRepository _repository;

        public ChungCuService(ChungCuRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<ChungCu>> GetAllWithImagesAsync()
        {
            return await _repository.GetAllWithImagesAsync();
        }
    }
}