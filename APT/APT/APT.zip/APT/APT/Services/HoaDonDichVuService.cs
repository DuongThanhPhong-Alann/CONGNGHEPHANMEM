﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;

using APT.Repositories;



    namespace APT.Services
{
    public class HoaDonDichVuService
    {
        private readonly HoaDonDichVuRepository _hoaDonDichVuRepository;

        public HoaDonDichVuService(HoaDonDichVuRepository hoaDonDichVuRepository)
        {
            _hoaDonDichVuRepository = hoaDonDichVuRepository;
        }

        // Lấy danh sách tất cả hóa đơn dịch vụ
        public async Task<IEnumerable<HoaDonDichVu>> GetAllAsync()
        {
            return await _hoaDonDichVuRepository.GetAllAsync();
        }

        // Lấy hóa đơn theo ID
        public async Task<HoaDonDichVu> GetByIdAsync(int id)
        {
            return await _hoaDonDichVuRepository.GetByIdAsync(id);
        }

        // Thêm hóa đơn dịch vụ mới
        public async Task AddAsync(HoaDonDichVu hoaDon)
        {
            await _hoaDonDichVuRepository.AddAsync(hoaDon);
        }

        // Cập nhật thông tin hóa đơn dịch vụ
        public async Task<bool> UpdateAsync(HoaDonDichVu hoaDon)
        {
            var existingHoaDon = await _hoaDonDichVuRepository.GetByIdAsync(hoaDon.ID);
            if (existingHoaDon == null) return false;

            existingHoaDon.ID_CanHo = hoaDon.ID_CanHo;
            existingHoaDon.ID_DichVu = hoaDon.ID_DichVu;
            existingHoaDon.ID_CuDan = hoaDon.ID_CuDan;
            existingHoaDon.NgayLap = hoaDon.NgayLap;
            existingHoaDon.SoTien = hoaDon.SoTien;
            existingHoaDon.TrangThaiThanhToan = hoaDon.TrangThaiThanhToan;

            await _hoaDonDichVuRepository.UpdateAsync(existingHoaDon);
            return true;
        }

        // Xóa hóa đơn dịch vụ theo ID
        public async Task<bool> DeleteAsync(int id)
        {
            var hoaDon = await _hoaDonDichVuRepository.GetByIdAsync(id);
            if (hoaDon == null) return false;

            await _hoaDonDichVuRepository.DeleteAsync(id);
            return true;
        }

        // Xử lý thanh toán hóa đơn dịch vụ
        public async Task<bool> ThanhToanDichVuAsync(int hoaDonId)
        {
            var hoaDon = await _hoaDonDichVuRepository.GetByIdAsync(hoaDonId);
            if (hoaDon == null) return false;

            hoaDon.TrangThaiThanhToan = true; // Đánh dấu đã thanh toán
            await _hoaDonDichVuRepository.UpdateAsync(hoaDon);
            return true;
        }
    }
}
