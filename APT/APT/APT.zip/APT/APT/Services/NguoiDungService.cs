﻿using System.Collections.Generic;
using System.Threading.Tasks;
using APT.Model;

using APT.Repositories;


namespace APT.Services
{
    public class NguoiDungService : ServiceBase<NguoiDung>
    {
        public NguoiDungService(NguoiDungRepository repository) : base(repository) { }
    }
}