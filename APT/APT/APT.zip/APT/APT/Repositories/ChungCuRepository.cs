﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace APT.Repositories
{
    public class ChungCuRepository : RepositoryBase<ChungCu>
    {
        public ChungCuRepository(ApplicationDbContext context) : base(context) { }

        public async Task<IEnumerable<ChungCu>> GetAllWithImagesAsync()
        {
            return await _context.ChungCus.Include(c => c.HinhAnhs).ToListAsync();
        }
    }
}