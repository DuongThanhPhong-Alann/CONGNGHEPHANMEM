﻿using APT.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace APT.Repositories
{
    public class CanHoRepository : RepositoryBase<CanHo>
    {
        public CanHoRepository(ApplicationDbContext context) : base(context) { }

        public async Task<IEnumerable<CanHo>> GetAllWithImagesAsync()
        {
            return await _context.CanHos.Include(c => c.HinhAnhs).ToListAsync();
        }
    }
}