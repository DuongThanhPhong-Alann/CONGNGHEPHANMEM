﻿namespace APT.Model
{
    public class PhanAnh
    {
        public int ID { get; set; }
        public int ID_NguoiDung { get; set; }
        public string? NoiDung { get; set; }
        public string? TrangThai { get; set; } // Chưa xử lý, Đang xử lý, Đã xử lý
        public DateTime NgayGui { get; set; } = DateTime.Now;

        // Khóa ngoại
        public NguoiDung NguoiDung { get; set; }
    }

}
