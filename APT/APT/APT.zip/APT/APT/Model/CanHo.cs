﻿namespace APT.Model
{
    public class CanHo
    {
        public int ID { get; set; }
        public string? MaCan { get; set; }
        public int ID_ChungCu { get; set; }
        public double DienTich { get; set; }
        public int SoPhong { get; set; }
        public decimal Gia { get; set; }
        public string? TrangThai { get; set; } // Đang bán, Đã bán, Cho thuê, Đã thuê

        // Khóa ngoại
        public ChungCu ChungCu { get; set; }
        public ICollection<HinhAnhCanHo> HinhAnhs { get; set; }
        public ICollection<CuDan> CuDans { get; set; }
    }

}
