﻿namespace APT.Model
{
    public class HinhAnhChungCu
    {
        public int ID { get; set; }
        public int ID_ChungCu { get; set; }
        public string? DuongDan { get; set; }

        // Khóa ngoại
        public ChungCu ChungCu { get; set; }
    }

}
