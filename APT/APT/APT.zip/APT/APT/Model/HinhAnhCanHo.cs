﻿namespace APT.Model
{
    public class HinhAnhCanHo
    {
        public int ID { get; set; }
        public int ID_CanHo { get; set; }
        public string? DuongDan { get; set; }

        // Khóa ngoại
        public CanHo CanHo { get; set; }
    }

}
