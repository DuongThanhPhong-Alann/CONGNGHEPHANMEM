﻿namespace APT.Model
{
    public class HoaDonDichVu
    {
        public int ID { get; set; }

        // Liên kết căn hộ và dịch vụ
        public int ID_CanHo { get; set; }
        public int ID_DichVu { get; set; }

        // Nếu muốn gắn với cư dân, thêm dòng này
        public int? ID_CuDan { get; set; }

        public DateTime NgayLap { get; set; } = DateTime.Now;
        public decimal SoTien { get; set; }

        // Dùng bool để tránh nhập lỗi dữ liệu
        public bool TrangThaiThanhToan { get; set; } = false; // false = Chưa thanh toán, true = Đã thanh toán

        // Khóa ngoại
        public CanHo CanHo { get; set; }
        public DichVu DichVu { get; set; }
        public CuDan? CuDan { get; set; } // Nếu muốn lưu thông tin cư dân thanh toán
    }
}
