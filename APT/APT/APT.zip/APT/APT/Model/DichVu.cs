﻿namespace APT.Model
{
    public class DichVu
    {
        public int ID { get; set; }
        public string? TenDichVu { get; set; }
        public string? MoTa { get; set; }
        public decimal Gia { get; set; }

        public ICollection<HoaDonDichVu> HoaDonDichVus { get; set; }
    }

}
