﻿namespace APT.Model
{
    public class CuDan
    {
        public int ID { get; set; }
        public int ID_NguoiDung { get; set; }
        public int ID_CanHo { get; set; }

        // Khóa ngoại
        public NguoiDung NguoiDung { get; set; }
        public CanHo CanHo { get; set; }
    }

}
