﻿namespace APT.Model
{
    public class NguoiDung
    {
        public int ID { get; set; }
        public string? HoTen { get; set; }
        public string? SoDienThoai { get; set; }
        public string? Email { get; set; }
        public string? MatKhau { get; set; }
        public string? LoaiNguoiDung { get; set; } // Cư dân, Ban quản lý, Khách

        public ICollection<CuDan> CuDans { get; set; }
        public ICollection<PhanAnh> PhanAnhs { get; set; }
    }

}
