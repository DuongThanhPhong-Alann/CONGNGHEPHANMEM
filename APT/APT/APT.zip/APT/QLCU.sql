﻿CREATE DATABASE QuanLyChungCu
GO
USE QuanLyChungCu
GO

-- Bảng Chung Cư
CREATE TABLE ChungCu (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    Ten NVARCHAR(255) NOT NULL,
    DiaChi NVARCHAR(255) NOT NULL,
    ChuDauTu NVARCHAR(255),
    NamXayDung INT,
    SoTang INT,
    MoTa NVARCHAR(MAX)
)

-- Bảng Căn Hộ
CREATE TABLE CanHo (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    MaCan NVARCHAR(50) UNIQUE NOT NULL,
    ID_ChungCu INT FOREIGN KEY REFERENCES ChungCu(ID) ON DELETE CASCADE,
    DienTich FLOAT NOT NULL,
    SoPhong INT NOT NULL,
    Gia DECIMAL(18,2) NOT NULL,
    TrangThai NVARCHAR(50) CHECK (TrangThai IN (N'Đang bán', N'Đã bán', N'Cho thuê', N'Đã thuê'))
)

-- Bảng Người Dùng
CREATE TABLE NguoiDung (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    SoDienThoai NVARCHAR(15) UNIQUE NOT NULL,
    Email NVARCHAR(100) UNIQUE,
    MatKhau NVARCHAR(255) NOT NULL,
    LoaiNguoiDung NVARCHAR(50) CHECK (LoaiNguoiDung IN (N'Cư dân', N'Ban quản lý', N'Khách'))
)

-- Bảng Cư Dân (Liên kết với Người Dùng)
CREATE TABLE CuDan (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    ID_NguoiDung INT FOREIGN KEY REFERENCES NguoiDung(ID) ON DELETE CASCADE,
    ID_CanHo INT FOREIGN KEY REFERENCES CanHo(ID) ON DELETE CASCADE
)

-- Bảng Dịch Vụ
CREATE TABLE DichVu (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TenDichVu NVARCHAR(255) NOT NULL,
    MoTa NVARCHAR(MAX),
    Gia DECIMAL(18,2) NOT NULL
)

-- Bảng Hóa Đơn Dịch Vụ
CREATE TABLE HoaDonDichVu (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    ID_CanHo INT FOREIGN KEY REFERENCES CanHo(ID) ON DELETE CASCADE,
    ID_DichVu INT FOREIGN KEY REFERENCES DichVu(ID) ON DELETE CASCADE,
    NgayLap DATE NOT NULL DEFAULT GETDATE(),
    SoTien DECIMAL(18,2) NOT NULL,
    TrangThai NVARCHAR(50) CHECK (TrangThai IN (N'Chưa thanh toán', N'Đã thanh toán'))
)

-- Bảng Phản Ánh & Khiếu Nại
CREATE TABLE PhanAnh (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    ID_NguoiDung INT FOREIGN KEY REFERENCES NguoiDung(ID) ON DELETE CASCADE,
    NoiDung NVARCHAR(MAX) NOT NULL,
    TrangThai NVARCHAR(50) CHECK (TrangThai IN (N'Chưa xử lý', N'Đang xử lý', N'Đã xử lý')),
    NgayGui DATETIME DEFAULT GETDATE()
)
CREATE TABLE HinhAnhChungCu (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    ID_ChungCu INT FOREIGN KEY REFERENCES ChungCu(ID) ON DELETE CASCADE,
    DuongDan NVARCHAR(MAX) NOT NULL -- Lưu đường dẫn ảnh
)

CREATE TABLE HinhAnhCanHo (
    ID INT IDENTITY(1,1) PRIMARY KEY,
    ID_CanHo INT FOREIGN KEY REFERENCES CanHo(ID) ON DELETE CASCADE,
    DuongDan NVARCHAR(MAX) NOT NULL -- Lưu đường dẫn ảnh
)